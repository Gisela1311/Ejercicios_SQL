INSERT INTO Categorias VALUES
('Entrantes'), 
('Ensaladas'), 
('Sopas'), 
('Cremas'), 
('Hortalizas'), 
('Legumbres'), 
('Huevos'), 
('Arroces'), 
('Pastas'), 
('Aves'), 
('Carnes'), 
('Pescados'), 
('Mariscos'), 
('Postres');
select * from Categorias;