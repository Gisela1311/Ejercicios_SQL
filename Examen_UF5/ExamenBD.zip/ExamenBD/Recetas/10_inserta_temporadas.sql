INSERT INTO Temporadas VALUES 
('Verano'),
('Invierno'),
('Primavera'),
('Oto�o');

select * from Temporadas;