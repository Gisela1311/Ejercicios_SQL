INSERT INTO Dificultades VALUES 
('Muy f�cil'),
('Elaborada'),
('Complicada');

select * from Dificultades;