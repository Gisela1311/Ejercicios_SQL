CREATE DATABASE RecetasBD;
GO
Use RecetasBD;
GO